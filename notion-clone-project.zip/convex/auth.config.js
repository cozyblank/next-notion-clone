export default {
  providers: [
    {
      domain: "https://sweeping-ant-85.clerk.accounts.dev",
      applicationID: "convex",
    },
  ],
};
